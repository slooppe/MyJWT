# CTF
## Root-me
### JSON Web Token (JWT) - Introduction
It's an introduction, this challenge is basic, you just need to understand how jwt work, and learn basic exploits and test these.
### JWT - Revoked token
With this challenge, you will see a developer try to secure her app, but you can bypass it, check [RFC 4648](https://tools.ietf.org/html/rfc4648)
### JSON Web Token (JWT) - Public key
With a public key, and alg used in jwt header, you can try RSA/HMAC confusion exploit.
## PentesterLab
### JWT I to XIII
For each challenge, read the course and checked my documentation, especially exploit section, all challenges can be resolved with only one command line with myjwt cli
