---
name: Enhancement request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: 'mBouamama'

---

[provide general introduction to the issue logging and why it is relevant to this repository]

## Context

[provide more detailed introduction to the issue itself and why it is relevant]

## Enhancement Request
[Explain exactly with link or screenshot for you enhancement request]
## Examples of command
[Write command in cli]
## Result wanted
[Give an example.]
